#ifndef ADC_H
#define ADC_H

void initADC();
int returnVoltage();
#endif