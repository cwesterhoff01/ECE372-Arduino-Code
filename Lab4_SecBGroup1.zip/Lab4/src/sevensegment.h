#ifndef SEVENSEGMENT_H
#define SEVENSEGMENT_H


void initPortC();
void selectLED(int num);
void start10();

#endif